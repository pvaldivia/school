/*
* @file doublylinkedlist.h Declaration of Doubly Linked List
*
* @brief
*  An implementation of a doubly linked list using nodes
*
* @author Pedro Valdivia
* @date 2016
*/

#ifndef DOUBLY_LINKED_LIST_H
#define DOUBLY_LINKED_LIST_H

#include<iostream>
#include<string>

using std::cout;
using std::cin;
using std::endl;
using std::string;

class DoublyLinkedList
{
    public:
    DoublyLinkedList();
    ~DoublyLinkedList();
    bool empty();                    //CHECKS TO SEE IF DLL IS EMPTY
    void append(const string&);      //INSERTS SONG INTO DLL
    void insertBefore(const string&);//INSERTS SONG BEFORE CURRENT SONG
    void insertAfter(const string&); //INSERTS SONG AFTER CURRENT SONG
    void remove(const string&);      //REMOVES CURRENT SONG
    void begin();                    //SETS CURRENT TO FIRST SONG
    void end();                      //SETS CURRENT TO LAST SONG
    bool next();                     //CHECKS IF THERE IS A SONG AFTER CURRENT
    bool prev();                     //CHECKS IF THERE IS A SONG BEFORE CURRENT
    bool find(const string&);        //FINDS A SONG IN THE DLL
    const string& getData();         //RETURNS THE CURRENT STRING

    private:
        class Node 
        {
            public:
            Node (string* data, Node *next, Node *prev)
            {m_data = data; m_next = next; m_prev = prev;}
            ~Node();
            string *m_data;
            Node *m_next;
            Node *m_prev;
        };
        Node *m_head;
        Node *m_tail;
        Node *m_current;

};

#endif

